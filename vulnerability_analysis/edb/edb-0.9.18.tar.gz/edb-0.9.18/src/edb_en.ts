<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="en_US">
<context>
    <name>ArchProcessor</name>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="75"/>
        <source>General Purpose</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="94"/>
        <source>Segments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="105"/>
        <source>FPU</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="118"/>
        <source>Debug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="132"/>
        <source>MMX</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="147"/>
        <source>XMM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="417"/>
        <source>move performed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="419"/>
        <source>move NOT performed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="453"/>
        <source>jump taken</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="455"/>
        <source>jump NOT taken</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="471"/>
        <source>return to %1 &lt;%2&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="473"/>
        <source>return to %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="678"/>
        <source>possible jump from 0x%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="758"/>
        <source>SYSCALL: read(%1,%2,%3)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="761"/>
        <source>SYSCALL: write(%1,%2,%3)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="764"/>
        <source>SYSCALL: open(%1,%2,%3)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="767"/>
        <source>SYSCALL: close(%1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="770"/>
        <source>SYSCALL: stat()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="773"/>
        <source>SYSCALL: fstat()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="776"/>
        <source>SYSCALL: lstat()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="779"/>
        <source>SYSCALL: poll()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="782"/>
        <source>SYSCALL: lseek()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="785"/>
        <source>SYSCALL: mmap(%1,%2,%3,%4,%5,%6)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="788"/>
        <source>SYSCALL: mprotect(%1,%2,%3)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="791"/>
        <source>SYSCALL: munmap(%1,%2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="794"/>
        <source>SYSCALL: brk(%1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="797"/>
        <source>SYSCALL: rt_sigaction()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="800"/>
        <source>SYSCALL: rt_sigprocmask()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="803"/>
        <source>SYSCALL: rt_sigreturn()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="806"/>
        <source>SYSCALL: ioctl()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="809"/>
        <source>SYSCALL: pread64()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="812"/>
        <source>SYSCALL: pwrite64()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="815"/>
        <source>SYSCALL: readv()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="818"/>
        <source>SYSCALL: writev()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="821"/>
        <source>SYSCALL: access()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="824"/>
        <source>SYSCALL: pipe()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="827"/>
        <source>SYSCALL: select()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="830"/>
        <source>SYSCALL: sched_yield()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="833"/>
        <source>SYSCALL: mremap()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="836"/>
        <source>SYSCALL: msync()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="839"/>
        <source>SYSCALL: mincore()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="842"/>
        <source>SYSCALL: madvise()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="845"/>
        <source>SYSCALL: shmget()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="848"/>
        <source>SYSCALL: shmat()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="851"/>
        <source>SYSCALL: shmctl()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="854"/>
        <source>SYSCALL: dup()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="857"/>
        <source>SYSCALL: dup2()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="860"/>
        <source>SYSCALL: pause()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="863"/>
        <source>SYSCALL: nanosleep()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="866"/>
        <source>SYSCALL: getitimer()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="869"/>
        <source>SYSCALL: alarm()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="872"/>
        <source>SYSCALL: setitimer()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="875"/>
        <source>SYSCALL: getpid()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="878"/>
        <source>SYSCALL: sendfile()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="881"/>
        <source>SYSCALL: socket()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="884"/>
        <source>SYSCALL: connect()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="887"/>
        <source>SYSCALL: accept()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="890"/>
        <source>SYSCALL: sendto()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="893"/>
        <source>SYSCALL: recvfrom()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="896"/>
        <source>SYSCALL: sendmsg()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="899"/>
        <source>SYSCALL: recvmsg()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="902"/>
        <source>SYSCALL: shutdown()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="905"/>
        <source>SYSCALL: bind()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="908"/>
        <source>SYSCALL: listen()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="911"/>
        <source>SYSCALL: getsockname()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="914"/>
        <source>SYSCALL: getpeername()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="917"/>
        <source>SYSCALL: socketpair()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="920"/>
        <source>SYSCALL: setsockopt()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="923"/>
        <source>SYSCALL: getsockopt()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="926"/>
        <source>SYSCALL: clone()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="929"/>
        <source>SYSCALL: fork()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="932"/>
        <source>SYSCALL: vfork()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="935"/>
        <source>SYSCALL: execve()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="938"/>
        <source>SYSCALL: exit()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="941"/>
        <source>SYSCALL: wait4()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="944"/>
        <source>SYSCALL: kill()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="947"/>
        <source>SYSCALL: uname()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="950"/>
        <source>SYSCALL: semget()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="953"/>
        <source>SYSCALL: semop()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="956"/>
        <source>SYSCALL: semctl()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="959"/>
        <source>SYSCALL: shmdt()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="962"/>
        <source>SYSCALL: msgget()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="965"/>
        <source>SYSCALL: msgsnd()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="968"/>
        <source>SYSCALL: msgrcv()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="971"/>
        <source>SYSCALL: msgctl()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="974"/>
        <source>SYSCALL: fcntl()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="977"/>
        <source>SYSCALL: flock()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="980"/>
        <source>SYSCALL: fsync()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="983"/>
        <source>SYSCALL: fdatasync()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="986"/>
        <source>SYSCALL: truncate()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="989"/>
        <source>SYSCALL: ftruncate()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="992"/>
        <source>SYSCALL: getdents()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="995"/>
        <source>SYSCALL: getcwd()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="998"/>
        <source>SYSCALL: chdir()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1001"/>
        <source>SYSCALL: fchdir()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1004"/>
        <source>SYSCALL: rename()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1007"/>
        <source>SYSCALL: mkdir()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1010"/>
        <source>SYSCALL: rmdir()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1013"/>
        <source>SYSCALL: creat()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1016"/>
        <source>SYSCALL: link()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1019"/>
        <source>SYSCALL: unlink()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1022"/>
        <source>SYSCALL: symlink()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1025"/>
        <source>SYSCALL: readlink(%1,%2,%3)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1028"/>
        <source>SYSCALL: chmod()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1031"/>
        <source>SYSCALL: fchmod()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1034"/>
        <source>SYSCALL: chown()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1037"/>
        <source>SYSCALL: fchown()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1040"/>
        <source>SYSCALL: lchown()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1043"/>
        <source>SYSCALL: umask()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1046"/>
        <source>SYSCALL: gettimeofday()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1049"/>
        <source>SYSCALL: getrlimit()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1052"/>
        <source>SYSCALL: getrusage()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1055"/>
        <source>SYSCALL: sysinfo()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1058"/>
        <source>SYSCALL: times()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1061"/>
        <source>SYSCALL: ptrace()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1064"/>
        <source>SYSCALL: getuid()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1067"/>
        <source>SYSCALL: syslog()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1070"/>
        <source>SYSCALL: getgid()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1073"/>
        <source>SYSCALL: setuid()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1076"/>
        <source>SYSCALL: setgid()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1079"/>
        <source>SYSCALL: geteuid()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1082"/>
        <source>SYSCALL: getegid()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1085"/>
        <source>SYSCALL: setpgid()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1088"/>
        <source>SYSCALL: getppid()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1091"/>
        <source>SYSCALL: getpgrp()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1094"/>
        <source>SYSCALL: setsid()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1097"/>
        <source>SYSCALL: setreuid()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1100"/>
        <source>SYSCALL: setregid()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1103"/>
        <source>SYSCALL: getgroups()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1106"/>
        <source>SYSCALL: setgroups()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1109"/>
        <source>SYSCALL: setresuid()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1112"/>
        <source>SYSCALL: getresuid()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1115"/>
        <source>SYSCALL: setresgid()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1118"/>
        <source>SYSCALL: getresgid()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1121"/>
        <source>SYSCALL: getpgid()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1124"/>
        <source>SYSCALL: setfsuid()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1127"/>
        <source>SYSCALL: setfsgid()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1130"/>
        <source>SYSCALL: getsid()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1133"/>
        <source>SYSCALL: capget()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1136"/>
        <source>SYSCALL: capset()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1139"/>
        <source>SYSCALL: rt_sigpending()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1142"/>
        <source>SYSCALL: rt_sigtimedwait()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1145"/>
        <source>SYSCALL: rt_sigqueueinfo()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1148"/>
        <source>SYSCALL: rt_sigsuspend()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1151"/>
        <source>SYSCALL: sigaltstack()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1154"/>
        <source>SYSCALL: utime()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1157"/>
        <source>SYSCALL: mknod()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1160"/>
        <source>SYSCALL: uselib()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1163"/>
        <source>SYSCALL: personality()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1166"/>
        <source>SYSCALL: ustat()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1169"/>
        <source>SYSCALL: statfs()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1172"/>
        <source>SYSCALL: fstatfs()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1175"/>
        <source>SYSCALL: sysfs()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1178"/>
        <source>SYSCALL: getpriority()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1181"/>
        <source>SYSCALL: setpriority()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1184"/>
        <source>SYSCALL: sched_setparam()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1187"/>
        <source>SYSCALL: sched_getparam()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1190"/>
        <source>SYSCALL: sched_setscheduler()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1193"/>
        <source>SYSCALL: sched_getscheduler()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1196"/>
        <source>SYSCALL: sched_get_priority_max()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1199"/>
        <source>SYSCALL: sched_get_priority_min()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1202"/>
        <source>SYSCALL: sched_rr_get_interval()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1205"/>
        <source>SYSCALL: mlock()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1208"/>
        <source>SYSCALL: munlock()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1211"/>
        <source>SYSCALL: mlockall()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1214"/>
        <source>SYSCALL: munlockall()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1217"/>
        <source>SYSCALL: vhangup()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1220"/>
        <source>SYSCALL: modify_ldt()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1223"/>
        <source>SYSCALL: pivot_root()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1226"/>
        <source>SYSCALL: _sysctl()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1229"/>
        <source>SYSCALL: prctl()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1232"/>
        <source>SYSCALL: arch_prctl()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1235"/>
        <source>SYSCALL: adjtimex()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1238"/>
        <source>SYSCALL: setrlimit()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1241"/>
        <source>SYSCALL: chroot()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1244"/>
        <source>SYSCALL: sync()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1247"/>
        <source>SYSCALL: acct()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1250"/>
        <source>SYSCALL: settimeofday()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1253"/>
        <source>SYSCALL: mount()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1256"/>
        <source>SYSCALL: umount2()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1259"/>
        <source>SYSCALL: swapon()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1262"/>
        <source>SYSCALL: swapoff()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1265"/>
        <source>SYSCALL: reboot()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1268"/>
        <source>SYSCALL: sethostname()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1271"/>
        <source>SYSCALL: setdomainname()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1274"/>
        <source>SYSCALL: iopl()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1277"/>
        <source>SYSCALL: ioperm()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1280"/>
        <source>SYSCALL: create_module()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1283"/>
        <source>SYSCALL: init_module()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1286"/>
        <source>SYSCALL: delete_module()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1289"/>
        <source>SYSCALL: get_kernel_syms()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1292"/>
        <source>SYSCALL: query_module()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1295"/>
        <source>SYSCALL: quotactl()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1298"/>
        <source>SYSCALL: nfsservctl()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1301"/>
        <source>SYSCALL: getpmsg()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1304"/>
        <source>SYSCALL: putpmsg()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1307"/>
        <source>SYSCALL: afs_syscall()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1310"/>
        <source>SYSCALL: tuxcall()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1313"/>
        <source>SYSCALL: security()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1316"/>
        <source>SYSCALL: gettid()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1319"/>
        <source>SYSCALL: readahead()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1322"/>
        <source>SYSCALL: setxattr()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1325"/>
        <source>SYSCALL: lsetxattr()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1328"/>
        <source>SYSCALL: fsetxattr()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1331"/>
        <source>SYSCALL: getxattr()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1334"/>
        <source>SYSCALL: lgetxattr()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1337"/>
        <source>SYSCALL: fgetxattr()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1340"/>
        <source>SYSCALL: listxattr()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1343"/>
        <source>SYSCALL: llistxattr()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1346"/>
        <source>SYSCALL: flistxattr()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1349"/>
        <source>SYSCALL: removexattr()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1352"/>
        <source>SYSCALL: lremovexattr()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1355"/>
        <source>SYSCALL: fremovexattr()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1358"/>
        <source>SYSCALL: tkill()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1361"/>
        <source>SYSCALL: time()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1364"/>
        <source>SYSCALL: futex()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1367"/>
        <source>SYSCALL: sched_setaffinity()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1370"/>
        <source>SYSCALL: sched_getaffinity()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1373"/>
        <source>SYSCALL: set_thread_area()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1376"/>
        <source>SYSCALL: io_setup()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1379"/>
        <source>SYSCALL: io_destroy()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1382"/>
        <source>SYSCALL: io_getevents()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1385"/>
        <source>SYSCALL: io_submit()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1388"/>
        <source>SYSCALL: io_cancel()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1391"/>
        <source>SYSCALL: get_thread_area()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1394"/>
        <source>SYSCALL: lookup_dcookie()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1397"/>
        <source>SYSCALL: epoll_create()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1400"/>
        <source>SYSCALL: epoll_ctl_old()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1403"/>
        <source>SYSCALL: epoll_wait_old()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1406"/>
        <source>SYSCALL: remap_file_pages()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1409"/>
        <source>SYSCALL: getdents64()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1412"/>
        <source>SYSCALL: set_tid_address()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1415"/>
        <source>SYSCALL: restart_syscall()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1418"/>
        <source>SYSCALL: semtimedop()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1421"/>
        <source>SYSCALL: fadvise64()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1424"/>
        <source>SYSCALL: timer_create()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1427"/>
        <source>SYSCALL: timer_settime()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1430"/>
        <source>SYSCALL: timer_gettime()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1433"/>
        <source>SYSCALL: timer_getoverrun()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1436"/>
        <source>SYSCALL: timer_delete()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1439"/>
        <source>SYSCALL: clock_settime()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1442"/>
        <source>SYSCALL: clock_gettime()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1445"/>
        <source>SYSCALL: clock_getres()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1448"/>
        <source>SYSCALL: clock_nanosleep()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1451"/>
        <source>SYSCALL: exit_group()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1454"/>
        <source>SYSCALL: epoll_wait()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1457"/>
        <source>SYSCALL: epoll_ctl()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1460"/>
        <source>SYSCALL: tgkill()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1463"/>
        <source>SYSCALL: utimes()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1466"/>
        <source>SYSCALL: vserver()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1469"/>
        <source>SYSCALL: mbind()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1472"/>
        <source>SYSCALL: set_mempolicy()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1475"/>
        <source>SYSCALL: get_mempolicy()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1478"/>
        <source>SYSCALL: mq_open()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1481"/>
        <source>SYSCALL: mq_unlink()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1484"/>
        <source>SYSCALL: mq_timedsend()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1487"/>
        <source>SYSCALL: mq_timedreceive()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1490"/>
        <source>SYSCALL: mq_notify()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1493"/>
        <source>SYSCALL: mq_getsetattr()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1496"/>
        <source>SYSCALL: kexec_load()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1499"/>
        <source>SYSCALL: waitid()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1502"/>
        <source>SYSCALL: add_key()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1505"/>
        <source>SYSCALL: request_key()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1508"/>
        <source>SYSCALL: keyctl()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1511"/>
        <source>SYSCALL: ioprio_set()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1514"/>
        <source>SYSCALL: ioprio_get()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1517"/>
        <source>SYSCALL: inotify_init()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1520"/>
        <source>SYSCALL: inotify_add_watch()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1523"/>
        <source>SYSCALL: inotify_rm_watch()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1526"/>
        <source>SYSCALL: migrate_pages()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1529"/>
        <source>SYSCALL: openat()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1532"/>
        <source>SYSCALL: mkdirat()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1535"/>
        <source>SYSCALL: mknodat()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1538"/>
        <source>SYSCALL: fchownat()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1541"/>
        <source>SYSCALL: futimesat()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1544"/>
        <source>SYSCALL: newfstatat()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1547"/>
        <source>SYSCALL: unlinkat()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1550"/>
        <source>SYSCALL: renameat()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1553"/>
        <source>SYSCALL: linkat()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1556"/>
        <source>SYSCALL: symlinkat()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1559"/>
        <source>SYSCALL: readlinkat()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1562"/>
        <source>SYSCALL: fchmodat()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1565"/>
        <source>SYSCALL: faccessat()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1568"/>
        <source>SYSCALL: pselect6()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1571"/>
        <source>SYSCALL: ppoll()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1574"/>
        <source>SYSCALL: unshare()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1577"/>
        <source>SYSCALL: set_robust_list()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1580"/>
        <source>SYSCALL: get_robust_list()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1583"/>
        <source>SYSCALL: splice()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1586"/>
        <source>SYSCALL: tee()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1589"/>
        <source>SYSCALL: sync_file_range()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1592"/>
        <source>SYSCALL: vmsplice()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1595"/>
        <source>SYSCALL: move_pages()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1598"/>
        <source>SYSCALL: utimensat()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1601"/>
        <source>SYSCALL: epoll_pwait()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1604"/>
        <source>SYSCALL: signalfd()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1607"/>
        <source>SYSCALL: timerfd_create()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1610"/>
        <source>SYSCALL: eventfd()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1613"/>
        <source>SYSCALL: fallocate()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1616"/>
        <source>SYSCALL: timerfd_settime()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1619"/>
        <source>SYSCALL: timerfd_gettime()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1622"/>
        <source>SYSCALL: accept4()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1625"/>
        <source>SYSCALL: signalfd4()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1628"/>
        <source>SYSCALL: eventfd2()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1631"/>
        <source>SYSCALL: epoll_create1()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1634"/>
        <source>SYSCALL: dup3()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1637"/>
        <source>SYSCALL: pipe2()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1640"/>
        <source>SYSCALL: inotify_init1()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1643"/>
        <source>SYSCALL: preadv()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arch/i386/ArchProcessor.cpp" line="1646"/>
        <source>SYSCALL: pwritev()</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BinaryStringWidget</name>
    <message>
        <location filename="binarystring.ui" line="15"/>
        <source>BinaryString</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="binarystring.ui" line="39"/>
        <source>UTF-16</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="binarystring.ui" line="49"/>
        <source>ASCII</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="binarystring.ui" line="68"/>
        <source>Hex</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CommentServer</name>
    <message>
        <location filename="CommentServer.cpp" line="77"/>
        <source>return to %1 &lt;%2&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="CommentServer.cpp" line="79"/>
        <source>return to %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="CommentServer.cpp" line="103"/>
        <source>ASCII &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="CommentServer.cpp" line="105"/>
        <source>UTF16 &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DebugEvent</name>
    <message>
        <location filename="os/win32/DebugEvent.cpp" line="258"/>
        <source>Illegal Access Fault</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="os/win32/DebugEvent.cpp" line="259"/>
        <source>&lt;p&gt;The debugged application encountered a segmentation fault.&lt;br /&gt;The address &lt;strong&gt;0x%1&lt;/strong&gt; could not be accessed.&lt;/p&gt;&lt;p&gt;If you would like to pass this exception to the application press Shift+[F7/F8/F9]&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="os/win32/DebugEvent.cpp" line="265"/>
        <source>Array Bounds Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="os/win32/DebugEvent.cpp" line="266"/>
        <source>&lt;p&gt;The debugged application tried to access an out of bounds array element.&lt;/p&gt;&lt;p&gt;If you would like to pass this exception to the application press Shift+[F7/F8/F9]&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="os/win32/DebugEvent.cpp" line="272"/>
        <source>Bus Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="os/win32/DebugEvent.cpp" line="273"/>
        <source>&lt;p&gt;The debugged application tried to read or write data that is misaligned.&lt;/p&gt;&lt;p&gt;If you would like to pass this exception to the application press Shift+[F7/F8/F9]&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="os/win32/DebugEvent.cpp" line="279"/>
        <location filename="os/win32/DebugEvent.cpp" line="287"/>
        <location filename="os/win32/DebugEvent.cpp" line="294"/>
        <location filename="os/win32/DebugEvent.cpp" line="301"/>
        <location filename="os/win32/DebugEvent.cpp" line="308"/>
        <location filename="os/win32/DebugEvent.cpp" line="315"/>
        <location filename="os/win32/DebugEvent.cpp" line="322"/>
        <source>Floating Point Exception</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="os/win32/DebugEvent.cpp" line="280"/>
        <source>&lt;p&gt;One of the operands in a floating-point operation is denormal. A denormal value is one that is too small to represent as a standard floating-point value.&lt;/p&gt;&lt;p&gt;If you would like to pass this exception to the application press Shift+[F7/F8/F9]&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="os/win32/DebugEvent.cpp" line="288"/>
        <source>&lt;p&gt;The debugged application tried to divide a floating-point value by a floating-point divisor of zero.&lt;/p&gt;&lt;p&gt;If you would like to pass this exception to the application press Shift+[F7/F8/F9]&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="os/win32/DebugEvent.cpp" line="295"/>
        <source>&lt;p&gt;The result of a floating-point operation cannot be represented exactly as a decimal fraction.&lt;/p&gt;&lt;p&gt;If you would like to pass this exception to the application press Shift+[F7/F8/F9]&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="os/win32/DebugEvent.cpp" line="302"/>
        <source>&lt;p&gt;The application attempted an invalid floating point operation.&lt;/p&gt;&lt;p&gt;If you would like to pass this exception to the application press Shift+[F7/F8/F9]&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="os/win32/DebugEvent.cpp" line="309"/>
        <source>&lt;p&gt;The exponent of a floating-point operation is greater than the magnitude allowed by the corresponding type.&lt;/p&gt;&lt;p&gt;If you would like to pass this exception to the application press Shift+[F7/F8/F9]&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="os/win32/DebugEvent.cpp" line="316"/>
        <source>&lt;p&gt;The stack overflowed or underflowed as the result of a floating-point operation.&lt;/p&gt;&lt;p&gt;If you would like to pass this exception to the application press Shift+[F7/F8/F9]&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="os/win32/DebugEvent.cpp" line="323"/>
        <source>&lt;p&gt;The exponent of a floating-point operation is less than the magnitude allowed by the corresponding type.&lt;/p&gt;&lt;p&gt;If you would like to pass this exception to the application press Shift+[F7/F8/F9]&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="os/win32/DebugEvent.cpp" line="329"/>
        <source>Illegal Instruction Fault</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="os/win32/DebugEvent.cpp" line="330"/>
        <source>&lt;p&gt;The debugged application attempted to execute an illegal instruction.&lt;/p&gt;&lt;p&gt;If you would like to pass this exception to the application press Shift+[F7/F8/F9]&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="os/win32/DebugEvent.cpp" line="336"/>
        <source>Page Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="os/win32/DebugEvent.cpp" line="337"/>
        <source>&lt;p&gt;The debugged application tried to access a page that was not present, and the system was unable to load the page.&lt;/p&gt;&lt;p&gt;If you would like to pass this exception to the application press Shift+[F7/F8/F9]&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="os/win32/DebugEvent.cpp" line="343"/>
        <source>Divide By Zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="os/win32/DebugEvent.cpp" line="344"/>
        <source>&lt;p&gt;The debugged application tried to divide an integer value by an integer divisor of zero.&lt;/p&gt;&lt;p&gt;If you would like to pass this exception to the application press Shift+[F7/F8/F9]&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="os/win32/DebugEvent.cpp" line="350"/>
        <source>Integer Overflow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="os/win32/DebugEvent.cpp" line="351"/>
        <source>&lt;p&gt;The result of an integer operation caused a carry out of the most significant bit of the result.&lt;/p&gt;&lt;p&gt;If you would like to pass this exception to the application press Shift+[F7/F8/F9]&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="os/win32/DebugEvent.cpp" line="357"/>
        <location filename="os/win32/DebugEvent.cpp" line="364"/>
        <source>Invalid Disposition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="os/win32/DebugEvent.cpp" line="358"/>
        <source>&lt;p&gt;An exception handler returned an invalid disposition to the exception dispatcher.&lt;/p&gt;&lt;p&gt;If you would like to pass this exception to the application press Shift+[F7/F8/F9]&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="os/win32/DebugEvent.cpp" line="365"/>
        <source>&lt;p&gt;The debugged application tried to continue execution after a non-continuable exception occurred.&lt;/p&gt;&lt;p&gt;If you would like to pass this exception to the application press Shift+[F7/F8/F9]&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="os/win32/DebugEvent.cpp" line="371"/>
        <source>Privileged Instruction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="os/win32/DebugEvent.cpp" line="372"/>
        <source>&lt;p&gt;The debugged application tried to execute an instruction whose operation is not allowed in the current machine mode.&lt;/p&gt;&lt;p&gt;If you would like to pass this exception to the application press Shift+[F7/F8/F9]&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="os/win32/DebugEvent.cpp" line="378"/>
        <source>Stack Overflow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="os/win32/DebugEvent.cpp" line="379"/>
        <source>&lt;p&gt;The debugged application has exhausted its stack.&lt;/p&gt;&lt;p&gt;If you would like to pass this exception to the application press Shift+[F7/F8/F9]&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DebuggerMain</name>
    <message>
        <location filename="DebuggerMain.cpp" line="216"/>
        <source>Ctrl+G</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="502"/>
        <source>&amp;Follow In Dump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="503"/>
        <source>&amp;Follow In Dump (New Tab)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="504"/>
        <source>&amp;Follow In Stack</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="531"/>
        <source>Register Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="548"/>
        <source>About edb</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="604"/>
        <location filename="DebuggerMain.cpp" line="618"/>
        <source>No Memory Found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="605"/>
        <location filename="DebuggerMain.cpp" line="619"/>
        <source>There appears to be no memory at that location (&lt;strong&gt;0x%1&lt;/strong&gt;)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="725"/>
        <source>Invalid Selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="726"/>
        <source>Please select %1 bytes to use this function.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="833"/>
        <source>Application Working Directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="852"/>
        <source>Enter value to push</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="884"/>
        <location filename="DebuggerMain.cpp" line="998"/>
        <location filename="DebuggerMain.cpp" line="1036"/>
        <source>&amp;Goto Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="885"/>
        <source>&amp;Goto %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="902"/>
        <source>&amp;Follow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="918"/>
        <source>Follow Constant In &amp;Dump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="921"/>
        <source>Follow Constant In &amp;Stack</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="931"/>
        <source>&amp;Set %1 to this Instruction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="933"/>
        <location filename="DebuggerMain.cpp" line="1003"/>
        <location filename="DebuggerMain.cpp" line="1038"/>
        <source>&amp;Edit Bytes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="934"/>
        <source>&amp;Fill with 00&apos;s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="935"/>
        <source>Fill with &amp;NOPs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="937"/>
        <source>&amp;Add Breakpoint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="938"/>
        <source>Add &amp;Conditional Breakpoint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="939"/>
        <source>&amp;Remove Breakpoint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="995"/>
        <location filename="DebuggerMain.cpp" line="1033"/>
        <source>Follow Address In &amp;CPU</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="996"/>
        <location filename="DebuggerMain.cpp" line="1034"/>
        <source>Follow Address In &amp;Dump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="997"/>
        <location filename="DebuggerMain.cpp" line="1035"/>
        <source>Follow Address In &amp;Stack</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="999"/>
        <location filename="DebuggerMain.cpp" line="1000"/>
        <source>Goto %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="1005"/>
        <source>&amp;Push %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="1006"/>
        <source>P&amp;op %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="1010"/>
        <source>&amp;Lock Stack</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="1040"/>
        <source>&amp;Save To File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="1059"/>
        <source>Save File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="1107"/>
        <source>Set Breakpoint Condition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="1107"/>
        <source>Expression:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="1299"/>
        <source>Stop Event</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="1300"/>
        <source>&lt;p&gt;The debugged has received a stop event. &lt;strong&gt;%1&lt;/strong&gt;&lt;/p&gt;&lt;p&gt;If you would like to pass this event to the application press Shift+[F7/F8/F9]&lt;/p&gt;&lt;p&gt;If you would like to ignore this event, press [F7/F8/F9]&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="1315"/>
        <source>Application Exited</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="1316"/>
        <source>The debugged application exited normally with exit code %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="1330"/>
        <source>Application Killed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="1330"/>
        <source>The debugged application was killed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="1423"/>
        <source>%1-%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="1425"/>
        <source>[%1] %2-%3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="1725"/>
        <source>edb</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="1824"/>
        <source>Not A Native Binary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="1825"/>
        <source>The program you just attached to was built for a different architecture than the one that edb was built for. For example a 32-bit binary on x86-64. This is not supported yet, so you may need to use a version of edb that was compiled for the same architecture as your target program</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="1961"/>
        <source>You may not debug a process which is a parent of the edb process.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="1897"/>
        <location filename="DebuggerMain.cpp" line="1911"/>
        <source>Could Not Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="434"/>
        <source>About Qt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="549"/>
        <source>&lt;p&gt;edb (Evan&apos;s Debugger) is designed to be an easy to use, modular, and cross platform debugger.&lt;/p&gt;&lt;p&gt;More information and updates can be found at &lt;a href=&quot;http://codef00.com&quot;&gt;http://codef00.com&lt;/a&gt;&lt;/p&gt;&lt;p&gt;You can also report bugs an feature requests at &lt;a href=&quot;http://bugs.codef00.com&quot;&gt;http://bugs.codef00.com&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Written by Evan Teran.&lt;/p&gt;&lt;p&gt;version: %1&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="1898"/>
        <source>The specified file (%1) does not appear to exist, please check privileges and try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="1912"/>
        <source>Failed to open and attach to process, please check privileges and try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="1960"/>
        <location filename="DebuggerMain.cpp" line="1971"/>
        <location filename="DebuggerMain.cpp" line="1991"/>
        <source>Attach</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="1972"/>
        <source>You are already debugging that process!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="1991"/>
        <source>Failed to attach to process, please check privileges and try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="2009"/>
        <source>Choose a file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="2215"/>
        <source>&amp;Set Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="2216"/>
        <source>&amp;Clear Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="2223"/>
        <source>Set Caption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerMain.cpp" line="2224"/>
        <source>Caption:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DebuggerUI</name>
    <message>
        <location filename="debuggerui.ui" line="15"/>
        <source>edb</source>
        <oldsource>EDB</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="debuggerui.ui" line="48"/>
        <location filename="debuggerui.ui" line="320"/>
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="debuggerui.ui" line="57"/>
        <source>&amp;View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="debuggerui.ui" line="65"/>
        <location filename="debuggerui.ui" line="430"/>
        <source>&amp;Plugins</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="debuggerui.ui" line="72"/>
        <source>&amp;Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="debuggerui.ui" line="80"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="debuggerui.ui" line="90"/>
        <source>&amp;Debug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="debuggerui.ui" line="117"/>
        <source>Registers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="debuggerui.ui" line="134"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="debuggerui.ui" line="144"/>
        <source>Data Dump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="debuggerui.ui" line="155"/>
        <source>00000000-00000000</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="debuggerui.ui" line="166"/>
        <source>Stack</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="debuggerui.ui" line="177"/>
        <source>ToolBar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="debuggerui.ui" line="199"/>
        <source>&amp;Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="debuggerui.ui" line="204"/>
        <source>&amp;Attach</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="debuggerui.ui" line="209"/>
        <source>E&amp;xit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="debuggerui.ui" line="214"/>
        <source>&amp;Memory Regions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="debuggerui.ui" line="217"/>
        <source>Ctrl+M</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="debuggerui.ui" line="222"/>
        <location filename="debuggerui.ui" line="289"/>
        <source>&amp;Step Into</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="debuggerui.ui" line="237"/>
        <source>&amp;Run</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="debuggerui.ui" line="240"/>
        <source>F9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="debuggerui.ui" line="252"/>
        <source>&amp;Pause</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="debuggerui.ui" line="255"/>
        <source>F11</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="debuggerui.ui" line="263"/>
        <source>&amp;Restart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="debuggerui.ui" line="271"/>
        <source>&amp;Detach</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="debuggerui.ui" line="274"/>
        <location filename="debuggerui.ui" line="277"/>
        <source>Detach</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="debuggerui.ui" line="292"/>
        <source>F7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="debuggerui.ui" line="304"/>
        <source>&amp;Step Over</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="debuggerui.ui" line="307"/>
        <source>F8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="debuggerui.ui" line="312"/>
        <source>&amp;About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="debuggerui.ui" line="323"/>
        <source>F1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="debuggerui.ui" line="331"/>
        <source>&amp;Toggle Breakpoint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="debuggerui.ui" line="334"/>
        <source>F2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="debuggerui.ui" line="339"/>
        <source>&amp;Configure Debugger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="debuggerui.ui" line="344"/>
        <source>About &amp;QT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="debuggerui.ui" line="349"/>
        <source>&amp;Breakpoint Manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="debuggerui.ui" line="354"/>
        <source>Application &amp;Arguments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="debuggerui.ui" line="359"/>
        <source>Run &amp;Until Return</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="debuggerui.ui" line="374"/>
        <source>&amp;Step Into (Pass Signal To Application)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="debuggerui.ui" line="377"/>
        <source>Shift+F7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="debuggerui.ui" line="389"/>
        <source>&amp;Step Over (Pass Signal To Application)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="debuggerui.ui" line="392"/>
        <source>Shift+F8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="debuggerui.ui" line="404"/>
        <source>&amp;Run (Pass Signal To Application)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="debuggerui.ui" line="407"/>
        <source>Shift+F9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="debuggerui.ui" line="412"/>
        <source>&amp;Recent Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="debuggerui.ui" line="417"/>
        <source>Application &amp;Working Directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="debuggerui.ui" line="425"/>
        <source>&amp;Kill</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="debuggerui.ui" line="435"/>
        <source>&amp;Threads</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="debuggerui.ui" line="438"/>
        <source>Ctrl+T</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerUI.cpp" line="87"/>
        <source>paused</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerUI.cpp" line="102"/>
        <source>running</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerUI.cpp" line="117"/>
        <source>terminated</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerUI.cpp" line="162"/>
        <location filename="DebuggerUI.cpp" line="164"/>
        <location filename="DebuggerUI.cpp" line="166"/>
        <source>edb output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerUI.cpp" line="229"/>
        <source>edb - %1 [%2]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerUI.cpp" line="291"/>
        <source>%1-%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerUI.cpp" line="335"/>
        <source>Goto Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DebuggerUI.cpp" line="335"/>
        <source>Address:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogArguments</name>
    <message>
        <location filename="dialog_arguments.ui" line="14"/>
        <source>Application Arguments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_arguments.ui" line="34"/>
        <location filename="dialog_arguments.ui" line="69"/>
        <source>+</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_arguments.ui" line="45"/>
        <location filename="dialog_arguments.ui" line="80"/>
        <source>-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DialogArguments.cpp" line="45"/>
        <source>New Argument</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogAttach</name>
    <message>
        <location filename="dialog_attach.ui" line="15"/>
        <source>Attach To Process</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_attach.ui" line="27"/>
        <source>Filter</source>
        <oldsource>Filter:</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_attach.ui" line="37"/>
        <source>Only Show Entries For My UID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_attach.ui" line="71"/>
        <source>PID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_attach.ui" line="76"/>
        <source>UID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_attach.ui" line="81"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogInputBinaryString</name>
    <message>
        <location filename="dialog_inputbinarystring.ui" line="15"/>
        <source>Input Binary String</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogInputValue</name>
    <message>
        <location filename="dialog_inputvalue.ui" line="21"/>
        <source>Input Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_inputvalue.ui" line="30"/>
        <source>Hexdecimal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_inputvalue.ui" line="43"/>
        <source>Signed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_inputvalue.ui" line="56"/>
        <source>Unsigned</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogMemoryRegions</name>
    <message>
        <location filename="dialog_memoryregions.ui" line="15"/>
        <source>Memory Regions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_memoryregions.ui" line="24"/>
        <source>Filter</source>
        <oldsource>Filter:</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DialogMemoryRegions.cpp" line="72"/>
        <source>Set Access</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DialogMemoryRegions.cpp" line="73"/>
        <source>No Access</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DialogMemoryRegions.cpp" line="74"/>
        <source>Read Only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DialogMemoryRegions.cpp" line="75"/>
        <source>Write Only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DialogMemoryRegions.cpp" line="76"/>
        <source>Execute Only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DialogMemoryRegions.cpp" line="77"/>
        <source>Read/Write</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DialogMemoryRegions.cpp" line="78"/>
        <source>Read/Execute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DialogMemoryRegions.cpp" line="79"/>
        <source>Write/Execute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DialogMemoryRegions.cpp" line="80"/>
        <source>Full Access</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DialogMemoryRegions.cpp" line="84"/>
        <source>View in &amp;CPU</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DialogMemoryRegions.cpp" line="85"/>
        <source>View in &amp;Stack</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DialogMemoryRegions.cpp" line="86"/>
        <source>View in &amp;Dump</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogOptions</name>
    <message>
        <location filename="dialog_options.ui" line="15"/>
        <source>Configure Debugger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_options.ui" line="28"/>
        <source>General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_options.ui" line="37"/>
        <source>Close Behaviour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_options.ui" line="46"/>
        <source>Detach From Debugged Application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_options.ui" line="56"/>
        <source>Terminate Debugged Application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_options.ui" line="80"/>
        <source>Appearance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_options.ui" line="91"/>
        <location filename="dialog_options.ui" line="144"/>
        <location filename="dialog_options.ui" line="151"/>
        <location filename="dialog_options.ui" line="161"/>
        <location filename="dialog_options.ui" line="456"/>
        <location filename="dialog_options.ui" line="591"/>
        <location filename="dialog_options.ui" line="611"/>
        <location filename="dialog_options.ui" line="631"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_options.ui" line="101"/>
        <source>Default Disassembly View Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_options.ui" line="111"/>
        <source>Default Stack View Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_options.ui" line="121"/>
        <source>Default Register View Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_options.ui" line="134"/>
        <source>Default Memory Dump View Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_options.ui" line="170"/>
        <source>Default Data View Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_options.ui" line="176"/>
        <source>Show Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_options.ui" line="183"/>
        <source>Show Hex</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_options.ui" line="190"/>
        <source>Show ASCII</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_options.ui" line="197"/>
        <source>Show Comments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_options.ui" line="204"/>
        <source>Word Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_options.ui" line="212"/>
        <location filename="dialog_options.ui" line="256"/>
        <source>1 Byte</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_options.ui" line="217"/>
        <location filename="dialog_options.ui" line="261"/>
        <source>2 Bytes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_options.ui" line="222"/>
        <location filename="dialog_options.ui" line="266"/>
        <source>4 Bytes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_options.ui" line="227"/>
        <location filename="dialog_options.ui" line="271"/>
        <source>8 Bytes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_options.ui" line="248"/>
        <source>Row Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_options.ui" line="276"/>
        <source>16 Bytes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_options.ui" line="302"/>
        <source>Show Semicolon in Addresses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_options.ui" line="341"/>
        <source>Debugging</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_options.ui" line="347"/>
        <source>Initial Breakpoint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_options.ui" line="356"/>
        <source>Application Entry Point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_options.ui" line="366"/>
        <source>&quot;main&quot; symbol (when possible)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_options.ui" line="379"/>
        <source>Warn when setting breakpoint in non-executable region</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_options.ui" line="386"/>
        <source>Use heuristic to find &quot;main&quot; symbol when it is not found in symbol file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_options.ui" line="395"/>
        <source>Minimum length for string detection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_options.ui" line="423"/>
        <source>Command Line IO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_options.ui" line="429"/>
        <source>Open a terminal to provide program input and output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_options.ui" line="439"/>
        <source>Terminal Program:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_options.ui" line="449"/>
        <source>/usr/bin/xterm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_options.ui" line="480"/>
        <source>Signals/Exceptions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_options.ui" line="486"/>
        <source>Ignore (pass to program) the following exceptions:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_options.ui" line="504"/>
        <source>Disassembly</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_options.ui" line="510"/>
        <source>Disassembly Syntax</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_options.ui" line="519"/>
        <source>Intel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_options.ui" line="532"/>
        <source>AT&amp;&amp;T</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_options.ui" line="542"/>
        <source>Instruction &quot;add byte ptr[eax], al&quot; (0x00 0x00) is &quot;Filling&quot; on x86</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_options.ui" line="549"/>
        <source>Disassemble in uppercase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_options.ui" line="570"/>
        <source>Directories</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_options.ui" line="578"/>
        <source>Symbol Directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_options.ui" line="598"/>
        <source>Plugin Directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_options.ui" line="618"/>
        <source>Session Directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_options.ui" line="654"/>
        <source>Plugin Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_options.ui" line="660"/>
        <source>No Plugin Option Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DialogOptions.cpp" line="98"/>
        <source>Choose a directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DialogOptions.cpp" line="110"/>
        <source>Choose Your Terminal Program</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogPlugins</name>
    <message>
        <location filename="dialog_plugins.ui" line="14"/>
        <source>Plugins</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_plugins.ui" line="36"/>
        <source>Filename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_plugins.ui" line="41"/>
        <source>Plugin Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_plugins.ui" line="46"/>
        <source>Author</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_plugins.ui" line="51"/>
        <source>Website</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogThreads</name>
    <message>
        <location filename="dialog_threads.ui" line="14"/>
        <source>Threads</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialog_threads.ui" line="42"/>
        <source>Thread ID</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MemoryRegions</name>
    <message>
        <location filename="os/win32/MemoryRegions.cpp" line="215"/>
        <source>Start Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="os/win32/MemoryRegions.cpp" line="217"/>
        <source>End Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="os/win32/MemoryRegions.cpp" line="219"/>
        <source>Permissions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="os/win32/MemoryRegions.cpp" line="221"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QDisassemblyView</name>
    <message>
        <location filename="widgets/QDisassemblyView.cpp" line="513"/>
        <source>invalid</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QHexView</name>
    <message>
        <location filename="qhexview/qhexview.cpp" line="198"/>
        <source>Set &amp;Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="qhexview/qhexview.cpp" line="200"/>
        <source>Show A&amp;ddress</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="qhexview/qhexview.cpp" line="201"/>
        <source>Show &amp;Hex</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="qhexview/qhexview.cpp" line="202"/>
        <source>Show &amp;Ascii</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="qhexview/qhexview.cpp" line="203"/>
        <source>Show &amp;Comments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="qhexview/qhexview.cpp" line="207"/>
        <source>Set Word Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="qhexview/qhexview.cpp" line="208"/>
        <source>1 Byte</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="qhexview/qhexview.cpp" line="209"/>
        <source>2 Bytes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="qhexview/qhexview.cpp" line="210"/>
        <source>4 Bytes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="qhexview/qhexview.cpp" line="211"/>
        <source>8 Bytes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="qhexview/qhexview.cpp" line="222"/>
        <source>Set Row Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="qhexview/qhexview.cpp" line="223"/>
        <source>1 Word</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="qhexview/qhexview.cpp" line="224"/>
        <source>2 Words</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="qhexview/qhexview.cpp" line="225"/>
        <source>4 Words</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="qhexview/qhexview.cpp" line="226"/>
        <source>8 Words</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="qhexview/qhexview.cpp" line="227"/>
        <source>16 Words</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="qhexview/qhexview.cpp" line="242"/>
        <source>&amp;Copy Selection To Clipboard</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RecentFileManager</name>
    <message>
        <location filename="RecentFileManager.cpp" line="86"/>
        <location filename="RecentFileManager.cpp" line="119"/>
        <source>Clear &amp;Menu</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>edb</name>
    <message>
        <location filename="Debugger.cpp" line="355"/>
        <location filename="Debugger.cpp" line="370"/>
        <source>Suspicious breakpoint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Debugger.cpp" line="356"/>
        <source>You want to place a breakpoint in a non-executable region.
An INT3 breakpoint set on data will not execute and may cause incorrect results or crashes.
Do you really want to set a breakpoint here?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Debugger.cpp" line="371"/>
        <source>It looks like you may be setting an INT3 breakpoint on data.
An INT3 breakpoint set on data will not execute and may cause incorrect results or crashes.
Do you really want to set a breakpoint here?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Debugger.cpp" line="389"/>
        <source>Error Setting Breakpoint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Debugger.cpp" line="390"/>
        <source>Sorry, but setting a breakpoint which is not in a valid region is not allowed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Debugger.cpp" line="457"/>
        <source>Error In Expression!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Debugger.cpp" line="481"/>
        <source>Input Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Debugger.cpp" line="897"/>
        <source>Overwritting breakpoint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Debugger.cpp" line="898"/>
        <source>You are attempting to modify bytes which overlap with a software breakpoint. Doing this will implicitly remove any breakpoints which are a conflict. Are you sure you want to do this?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Debugger.cpp" line="921"/>
        <source>Edit Binary String</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main.cpp" line="120"/>
        <source>edb Failed To Load A Necessary Plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main.cpp" line="121"/>
        <source>Failed to successfully load the debugger core plugin. Please make sure it exists and that the plugin path is correctly configured.
This is normal if edb has not been previously run or the configuration file has been removed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main.cpp" line="129"/>
        <source>edb</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main.cpp" line="130"/>
        <source>edb will now close. If you were successful in specifying the location of the debugger core plugin, please run edb again.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
